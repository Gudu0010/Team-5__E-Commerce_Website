import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-roles-permissions',
  templateUrl: './roles-permissions.component.html',
  styleUrls: ['./roles-permissions.component.css']
})
export class RolesPermissionsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
