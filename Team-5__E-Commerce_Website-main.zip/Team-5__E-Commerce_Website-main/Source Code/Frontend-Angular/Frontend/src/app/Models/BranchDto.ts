export class BranchDto{
    branchId : number;
    branchRegion: string;
    branchCity: string;
}