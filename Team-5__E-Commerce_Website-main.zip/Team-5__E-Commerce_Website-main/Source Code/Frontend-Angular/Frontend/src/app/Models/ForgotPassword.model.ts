export class ForgotPassword{
    emailId:String;
    security_question:String;
    security_answer:String;
    newPassword:String;
    reEnterNewPassword:String;
}