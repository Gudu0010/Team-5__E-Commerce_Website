import { User } from './User.model';
import { Address1 } from './Address.model';

export class SignUp{
    user:User;
    address:Address1;
}