export class NewUser{
    emailId:String;
    password:String;
}