export class Address1{
    line1:String;
    line2:String;
    landmark:String;
    city:String;
    mobileNumber:String;
}