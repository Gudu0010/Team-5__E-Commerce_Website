import { FilterParameterPipe } from './filter-parameter.pipe';

describe('FilterParameterPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterParameterPipe();
    expect(pipe).toBeTruthy();
  });
});
