import { SearchItemsPipe } from './search-items.pipe';

describe('SearchItemsPipe', () => {
  it('create an instance', () => {
    const pipe = new SearchItemsPipe();
    expect(pipe).toBeTruthy();
  });
});
