import { SortItemsPipe } from './sort-items.pipe';

describe('SortItemsPipe', () => {
  it('create an instance', () => {
    const pipe = new SortItemsPipe();
    expect(pipe).toBeTruthy();
  });
});
