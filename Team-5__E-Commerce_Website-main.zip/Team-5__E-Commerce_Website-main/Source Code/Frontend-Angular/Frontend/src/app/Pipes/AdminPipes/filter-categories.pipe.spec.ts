import { FilterCategoriesPipe } from './filter-categories.pipe';

describe('FilterCategoriesPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterCategoriesPipe();
    expect(pipe).toBeTruthy();
  });
});
