import { MergeArrayPipe } from './merge-array.pipe';

describe('MergeArrayPipe', () => {
  it('create an instance', () => {
    const pipe = new MergeArrayPipe();
    expect(pipe).toBeTruthy();
  });
});
