import { FilterOrdersPipe } from './filter-orders.pipe';

describe('FilterOrdersPipe', () => {
  it('create an instance', () => {
    const pipe = new FilterOrdersPipe();
    expect(pipe).toBeTruthy();
  });
});
