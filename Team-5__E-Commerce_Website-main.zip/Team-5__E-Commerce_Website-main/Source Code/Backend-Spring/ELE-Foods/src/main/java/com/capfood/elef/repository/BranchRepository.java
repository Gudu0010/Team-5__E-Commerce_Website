package com.capfood.elef.repository;


import org.springframework.data.jpa.repository.JpaRepository;

import com.capfood.elef.entities.Branch;

public interface BranchRepository extends JpaRepository<Branch, Integer>{

}
