package com.capfood.elef;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EleFoodsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EleFoodsApplication.class, args);
	}

}
